import math
import requests

url = "https://api.binance.com/api/v3/ticker/price"
response = requests.get(url)
data = response.json()

usdt_pairs = []
for item in data:
    if item["symbol"].endswith("USDT"):
        usdt_pairs.append(item)

main_currencies = {
    "BTC","ETH","BNB","XRP","ADA","SOL","DOGE","DOT","MATIC","LTC",
    "BCH","LINK","XLM","ETC","TRX","EOS","NEAR","VET","XMR","FIL",
    "ATOM","AAVE","ICP","SAND","MANA","FTM","ALGO","KSM","AVAX","USDT"
}

edges = []
for item in usdt_pairs:
    symbol = item["symbol"]
    if symbol.endswith("USDT"):
        base = symbol.replace("USDT", "")
        if base in main_currencies:
            rate = float(item["price"])
            if rate > 0:
                edges.append((base, "USDT", rate))
                edges.append(("USDT", base, 1/rate))

def bellman_ford(graph, start_node):
    vertices = {v for edge in graph for v in edge[:2]}
    print("Vertices:", vertices)
    weighted_edges = [(from_curr, to_curr, -math.log(rate)) for (from_curr, to_curr, rate) in graph]
    print("Weighted_edges:", weighted_edges)
    parent = {v: None for v in vertices}
    print("Parent:", parent)
    distances = {v: 0 if v == start_node else float('inf') for v in vertices}
    print(distances)
    for _ in range(len(vertices) - 1):
        for from_curr, to_curr, weight in weighted_edges:
            if distances[from_curr] != float('inf') and distances[to_curr] > distances[from_curr] + weight:
                distances[to_curr] = distances[from_curr] + weight
                parent[to_curr] = from_curr
    cycle = None
    for from_curr, to_curr, weight in weighted_edges:
        if distances[to_curr] > distances[from_curr] + weight:
            print("negative cycle")
            cycle_node = to_curr
            for _ in range(len(vertices)):
                cycle_node = parent[cycle_node]
            cycle = []
            current = cycle_node
            while True:
                cycle.append(current)
                current = parent[current]
                if current == cycle_node:
                    cycle.append(current)
                    break
    return distances, parent, cycle

distances, parent, cycle = bellman_ford(graph=edges, start_node="USDT")
if cycle is None:
    print("There are no cycles")
else:
    print("The cycle was found", cycle[::-1])
    cycle = cycle[::-1]
    profit = 1
    for i in range(len(cycle) - 1):
        for from_curr, to_curr, rate in edges:
            if from_curr == cycle[i] and to_curr == cycle[i + 1]:
                profit *= rate
                break
    print("Profit in this cycle", profit)



