from flask import Flask, jsonify, render_template
from arbitrage import find_arbitrage
from test import get_test_graph

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/arbitrage")
def arbitrage():
    edges = get_test_graph()
    top_cycles = find_arbitrage(edges)
    print(top_cycles)
    return jsonify(top_cycles)

if __name__ == "__main__":
    app.run(debug=True)