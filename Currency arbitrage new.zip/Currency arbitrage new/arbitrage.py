import math

def bellman_ford(graph):
    vertices = {v for edge in graph for v in edge[:2]}
    weighted_edges = [(from_curr, to_curr, -math.log(rate)) for (from_curr, to_curr, rate) in graph]
    all_cycles = []
    for start_node in vertices:
        parent = {v: None for v in vertices}
        distances = {v: 0 if v == start_node else float('inf') for v in vertices}
        for _ in range(len(vertices) - 1):
            for from_curr, to_curr, weight in weighted_edges:
                if distances[from_curr] != float('inf') and distances[to_curr] > distances[from_curr] + weight:
                    distances[to_curr] = distances[from_curr] + weight
                    parent[to_curr] = from_curr
    for from_curr, to_curr, weight in weighted_edges:
        if distances[from_curr] != float('inf') and distances[to_curr] > distances[from_curr] + weight:
            cycle_node = to_curr
            for _ in range(len(vertices)):
                cycle_node = parent[cycle_node]
            cycle = []
            current = cycle_node
            while True:
                cycle.append(current)
                current = parent[current]
                if current == cycle_node and len(cycle) > 1:
                    cycle.append(current)
                    break
            cycle = cycle[::-1]
            if cycle not in all_cycles:
                all_cycles.append(cycle)
    return all_cycles

def calculate_profit(cycle, edges):
    profit = 1
    for i in range(len(cycle) - 1):
        for from_curr, to_curr, rate in edges:
            if from_curr == cycle[i] and to_curr == cycle[i + 1]:
                profit *= rate
                break
    return profit

def find_arbitrage(edges):
    cycles = bellman_ford(edges)
    if not cycles:
        return []
    results = []
    for cycle in cycles:
        profit = calculate_profit(cycle, edges)
        if profit > 1.001:
            results.append({
                "cycle": cycle,
                    "profit": round(profit, 6)
            })
    results.sort(key=lambda x: x["profit"], reverse=True)
    return results[:5]


