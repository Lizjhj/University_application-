import random

def get_test_graph():
    currencies = [
        "USDT","BTC","ETH","BNB","XRP","ADA","SOL","DOGE","DOT","MATIC",
        "LTC","BCH","LINK","XLM","ETC","TRX","EOS","NEAR","VET","XMR",
        "FIL","ATOM","AAVE","ICP","SAND","MANA","FTM","ALGO","KSM","AVAX"
    ]

    edges = [
        ("USDT", "BTC", 1),
        ("BTC", "ETH", 2),
        ("ETH", "USDT", 0.6),

        ("USDT", "ADA", 1),
        ("ADA", "SOL", 1.5),
        ("SOL", "DOGE", 1.2),
        ("DOGE", "USDT", 0.7),

        ("USDT", "BNB", 1),
        ("BNB", "XRP", 3),
        ("XRP", "USDT", 0.4),

        ("USDT", "MATIC", 1),
        ("MATIC", "LTC", 1.3),
        ("LTC", "LINK", 1.2),
        ("LINK", "XLM", 1.1),
        ("XLM", "USDT", 0.7),

        ("USDT", "FIL", 1),
        ("FIL", "ATOM", 1.2),
        ("ATOM", "USDT", 0.9),
    ]

    for i in range(len(currencies)):
        for j in range(i+1, len(currencies)):
            a, b = currencies[i], currencies[j]
            if not any(e[0]==a and e[1]==b for e in edges):
                rate = round(random.uniform(0.5, 2.0), 2)
                edges.append((a, b, rate))
                edges.append((b, a, 1/rate))
    return edges