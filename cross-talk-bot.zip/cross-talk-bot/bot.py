import asyncio
import sqlite3
from aiogram import Bot, Dispatcher
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.filters import Command
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage


TOKEN = "ITS A SECRET"
DB_NAME = "events.db"
bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())

class Form(StatesGroup):
    language = State()
    event_choice = State()
    name = State()
    licey = State()
    group = State()
    university = State()
    passport = State()


#script for conversation
TEXT = {
    "ru": {
        "ask_name": "Как тебя зовут?",
        "select_event": "Выберите мероприятие:",
        "licey": "Ты из лицея?",
        "group": "Напиши свою группу (например: 10В1, 10В2):",
        "university": "Напиши университет:",
        "passport": "Введи серию и номер паспорта (10 цифр без пробелов):",
        "success": "✅ Регистрация прошла успешно!\nВы зарегистрировались на событие: {}",
        "full": "⚠ К сожалению, на мероприятие '{}' все места заняты!",
        "invalid": "Пожалуйста, используй кнопки 👇"
    },
    "cn": {
        "ask_name": "你叫什么名字？",
        "select_event": "请选择活动：",
        "licey": "你是否在HSE Lyceum 学习？？",
        "group": "请输入你的班级：",
        "university": "请输入你的大学：",
        "passport": "请输入护照号码（10位数字）：",
        "success": "✅ 报名成功！\n你已报名参加活动: {}",
        "full": "⚠ 很抱歉，活动 '{}' 已满员！",
        "invalid": "请使用下面的按钮 👇"
    }
}


# check if the table exists
def ensure_users_table():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            event_name TEXT NOT NULL,
            event_date TEXT NOT NULL,
            event_type TEXT NOT NULL,
            licey TEXT,
            group_name TEXT,
            university TEXT,
            passport TEXT)
    """)
    conn.commit()
    conn.close()
ensure_users_table()


async def save_user(state: FSMContext):
    data = await state.get_data()
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO users (name, event_name, event_date, event_type, licey, group_name, university, passport)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data.get("name"),
        data.get("event_name"),
        data.get("event_date"),
        data.get("event_type"),
        data.get("licey"),
        data.get("group"),
        data.get("university"),
        data.get("passport")
    ))
    conn.commit()
    conn.close()


@dp.message(Command("start"))
async def start(message: Message, state: FSMContext):
    await state.clear()
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="Русский"), KeyboardButton(text="中文")]],
        resize_keyboard=True
    )
    await message.answer("Выберите язык / 请选择语言", reply_markup=kb)
    await state.set_state(Form.language)


def get_all_events():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT topic, date, time FROM offline_events")
    offline = cursor.fetchall()
    cursor.execute("SELECT topic, date, time FROM online_events")
    online = cursor.fetchall()
    conn.close()
    return offline, online

@dp.message(Form.language)
async def choose_language(message: Message, state: FSMContext):
    if message.text not in ["Русский", "中文"]:
        await message.answer("Пожалуйста, выбери язык кнопкой 👇")
        return
    if message.text == "Русский":
         lang= "ru"
    else: lang= "cn"
    await state.update_data(language=lang)
    offline, online = get_all_events()
    buttons = []
    topic_mapping = {}
    for ev in offline:
        text = f"{ev[0]} ({ev[1]} {ev[2]}) [Офлайн]"
        buttons.append([KeyboardButton(text=text)])
        topic_mapping[text] = ev[0]
    for ev in online:
        text = f"{ev[0]} ({ev[1]} {ev[2]}) [Онлайн]"
        buttons.append([KeyboardButton(text=text)])
        topic_mapping[text] = ev[0]
    kb_events = ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True, one_time_keyboard=True)
    await state.update_data(topic_mapping=topic_mapping, kb_events=kb_events)
    await message.answer(TEXT[lang]["select_event"], reply_markup=kb_events)
    await state.set_state(Form.event_choice)

@dp.message(Form.event_choice)
async def choose_event(message: Message, state: FSMContext):
    data = await state.get_data()
    lang = data.get("language", "ru")
    topic_mapping = data.get("topic_mapping", {})
    kb_events = data.get("kb_events")
    if message.text not in topic_mapping:
        await message.answer(TEXT[lang]["invalid"], reply_markup=kb_events)
        return
    event_name = topic_mapping[message.text]
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    if "[Офлайн]" in message.text:
        event_type = "offline"
        cursor.execute("SELECT max_participants, date FROM offline_events WHERE topic=?", (event_name,))
        result = cursor.fetchone()
        if not result:
            await message.answer("Мероприятие не найдено", reply_markup=ReplyKeyboardRemove())
            conn.close()
            return
        max_participants, event_date = result
        cursor.execute("SELECT COUNT(*) FROM users WHERE event_name=? AND event_type='offline'", (event_name,))
        count_registered = cursor.fetchone()[0]
        if count_registered >= max_participants:
            await message.answer(TEXT[lang]["full"].format(event_name), reply_markup=ReplyKeyboardRemove())
            conn.close()
            return
    else:
        event_type = "online"
        cursor.execute("SELECT date FROM online_events WHERE topic=?", (event_name,))
        result = cursor.fetchone()
        if not result:
            await message.answer("Мероприятие не найдено", reply_markup=ReplyKeyboardRemove())
            conn.close()
            return
        event_date = result[0]
    conn.close()
    await state.update_data(event_name=event_name, event_date=event_date, event_type=event_type)
    await message.answer(TEXT[lang]["ask_name"], reply_markup=ReplyKeyboardRemove())
    await state.set_state(Form.name)

#fill in your name
@dp.message(Form.name)
async def get_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    data = await state.get_data()
    lang = data.get("language", "ru")
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="Да"), KeyboardButton(text="Нет")]] if lang == "ru"
        else [[KeyboardButton(text="是"), KeyboardButton(text="否")]],
        resize_keyboard=True
    )
    await message.answer(TEXT[lang]["licey"], reply_markup=kb)
    await state.set_state(Form.licey)


#Lyceum
@dp.message(Form.licey)
async def licey_choice(message: Message, state: FSMContext):
    data = await state.get_data()
    lang = data.get("language", "ru")
    licey_yes = "да" if lang == "ru" else "是"
    licey_no = "нет" if lang == "ru" else "否"
    kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=licey_yes),KeyboardButton(text=licey_no)]], resize_keyboard=True)
    if message.text.lower() not in [licey_yes, licey_no]:
        await message.answer(TEXT[lang]["invalid"], reply_markup=kb)
        return
    if message.text.lower() == licey_yes:
        await state.update_data(licey="yes")
        await message.answer(TEXT[lang]["group"], reply_markup=ReplyKeyboardRemove())
        await state.set_state(Form.group)
    else:
        await state.update_data(licey="no")
        await message.answer(TEXT[lang]["university"], reply_markup=ReplyKeyboardRemove())
        await state.set_state(Form.university)

#If you study in Lyceum or higher school of economics only one thing you need to do is filling in your group
@dp.message(Form.group)
async def group(message: Message, state: FSMContext):
    await state.update_data(group=message.text.strip())
    await save_user(state)
    data = await state.get_data()
    lang = data.get("language", "ru")
    await message.answer(TEXT[lang]["success"].format(data["event_name"]), reply_markup=ReplyKeyboardRemove())
    await state.clear()

#if you do not study in Lyceum
@dp.message(Form.university)
async def university(message: Message, state: FSMContext):
    await state.update_data(university=message.text.strip())
    data = await state.get_data()
    lang = data.get("language", "ru")
    if data.get("event_type") == "online":
        await save_user(state)
        await message.answer(TEXT[lang]["success"].format(data["event_name"]), reply_markup=ReplyKeyboardRemove())
        await state.clear()
    else:
        await message.answer(TEXT[lang]["passport"], reply_markup=ReplyKeyboardRemove())
        await state.set_state(Form.passport)


#passport info
@dp.message(Form.passport)
async def passport(message: Message, state: FSMContext):
    data = await state.get_data()
    lang = data.get("language", "ru")
    if not message.text or not message.text.isdigit() or len(message.text) != 10:
        await message.answer(TEXT[lang]["passport"])
        return
    await state.update_data(passport=message.text.strip())
    await save_user(state)
    data = await state.get_data()
    await message.answer(TEXT[lang]["success"].format(data["event_name"]), reply_markup=ReplyKeyboardRemove())
    await state.clear()


@dp.message()
async def fallback(message: Message, state: FSMContext):
    data = await state.get_data()
    lang = data.get("language", "ru")
    current_state = await state.get_state()
    if current_state == Form.language.state:
        await message.answer("Пожалуйста, выбери язык кнопкой 👇")
    elif current_state == Form.event_choice.state:
        kb_events = data.get("kb_events")
        await message.answer(TEXT[lang]["invalid"], reply_markup=kb_events)
    elif current_state == Form.licey.state:
        await message.answer(TEXT[lang]["invalid"])
    elif current_state == Form.passport.state:
        await message.answer(TEXT[lang]["passport"])
    else:
        pass


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())